﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkedList
{
    class Link
    {
        public int data;
        public Link previous;
        public Link next;
        public Link(int data)
        {
            previous = null;
            this.data = data;
            next = null;

        }
        public Link(Link previous, int data, Link next)
        {
            this.previous = previous;
            this.data = data;
            this.next = next;
        }
    }
    class DoubleLinkList
    {
        public Link head;
        public int count;
        public DoubleLinkList()
        {
            head = null;
            count = 0;
           
        }
        public void insertBegin(int data)
        {
            if (head == null)
                head = new Link(null, data, null);
            else
            {
                Link newLink = new Link(null, data, head);
                head.previous = newLink;
                head = newLink;
            }
            count++;
        }
        public void insertEnd(int data)
        {
            if (head == null)
                head = new Link(null, data, null);
            else
            {
                Link current = head;
                while (current.next != null)
                {
                    current = current.next;

                }
                Link newLink = new Link(current, data, null);
                current.next = newLink;
            }
            count++;
        }
        public void deleteBegin()
        {

            if (head == null)
                Console.WriteLine("No elements in the list - Deletion not possible");
            else
            {
                Link temp = head;
                head = head.next;
                Console.WriteLine("Deleting the node with value="+ temp.data);
                temp.previous = null;
                count--;
            }
        }
        public void deleteEnd()
        {
            if (head == null)
                Console.WriteLine("No elements in the list - Deletion not possible");
            else if (head.next == null)
            {
                head = null;
                count--;
            }
            Link current = head;
            while (current.next.next != null)
            {
                current = current.next;
            }
            Console.WriteLine("Deleting the nod with value="+current.next.data);
            current.next = null;
            count--;
        }
        public void insertPos(int data, int pos)
        {
           
             if (pos < 1 || pos > count+1)
                Console.WriteLine("we can't insert");
            Link current = head;
            int i = 1;

           
            while (i < pos)
            {
                current = current.next;
                i++;
            }
           

             if (current.previous == null)
            {
                Link newLink = new Link(null, data, current);
                current.previous = newLink;
                head = newLink;
            }
            else
            {

                Link newLink = new Link(current.previous, data, current);
                current.previous.next = newLink;
                current.previous = newLink;
            }
            count++;
        }
        public void deletepos(int pos)
        {
            if (head == null)
                Console.WriteLine("No elements in the list - Deletion not possible");
            if (pos < 1 || pos > count+1)
                Console.WriteLine("we can't delete");
            Link current = head;
            int i = 1;
            
            while (i < pos)
            {
                current = current.next;
                i++;
            }
            if (current.next == null)
            {
                current.previous.next = null;
            }
            else if (current.previous == null)
            {
                current = current.next;
                current.previous = null;
                head = current;
            }
            else
            {
                current.previous.next = current.next;
                current.next.previous = current.previous;
            }
            count--;
        }
        public void Find(int data)
        {

            int pos = 0;
            if (head == null)
                Console.WriteLine("Linked list empty");
           Link current = head;
            while (current != null)
            {
                pos++;
                if (current.data == data)
                {
                    Console.WriteLine("data found at position" + data, pos);
                }
                if (current.next != null)
                    current = current.next;
                else
                    break;
            }
            Console.WriteLine("the  data not found" + data);


        }
        public void FindPos(int data,int n)
        {

            int pos = 0;
            if (head == null)
                Console.WriteLine("Linked list empty");
            Link current = head;
            while (current != null)
            {
                pos++;
                if (current.data == data && pos==n)
                {
                    Console.WriteLine("data found at position" + data, pos);
                }
                if (current.next != null)
                    current = current.next;
                else
                    break;
            }
            Console.WriteLine("the  data not found" + data);


        }
        public void display()
        {
            Link current = head;
            while (current != null)
            {
                Console.Write(current.data+" ");
                current = current.next;
            }
            Console.WriteLine();
        }
    }
}
