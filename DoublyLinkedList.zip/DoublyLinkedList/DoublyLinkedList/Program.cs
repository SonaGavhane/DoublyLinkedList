﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            DoubleLinkList ddl = new DoubleLinkList();
            int ch,data,pos;

            do
            {
                Console.WriteLine("1 Insert in the beginning");
                Console.WriteLine("2 Insert in the end");
                Console.WriteLine("3 Insert in the given position");
                Console.WriteLine("4.Delete at the beginning");
                Console.WriteLine("5.Delete at the end");
                Console.WriteLine("6.Delete at the given position");
                Console.WriteLine("7.find the data:");
                Console.WriteLine("8.find data at given position");
                Console.WriteLine("9. Display");
                Console.WriteLine("10. Exit");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("enter the data:");
                         data = int.Parse(Console.ReadLine());
                        ddl.insertBegin(data);
                        break;
                    case 2:
                        Console.WriteLine("enter the data:");
                        data = int.Parse(Console.ReadLine());
                        ddl.insertEnd(data);
                        break;
                    case 3:
                        Console.WriteLine("Enter the element ");
                        data = int.Parse(Console.ReadLine());

                        do
                        {
                            Console.WriteLine("Enter position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ddl.count + 1);

                        ddl.insertPos(data, pos);
                        break;
                    case 4:ddl.deleteBegin();
                        break;
                    case 5:
                        ddl.deleteEnd();
                        break;
                    case 6:
                        do
                        {
                            Console.WriteLine("Enter position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ddl.count+1);
                        ddl.deletepos(pos);
                        break;
                    case 7:Console.WriteLine("enter the element");
                        data = int.Parse(Console.ReadLine());
                        ddl.Find(data);
                        break;
                    case 8:
                        Console.WriteLine("enter the element");
                        data = int.Parse(Console.ReadLine());
                        Console.WriteLine("enter the possition");
                        pos = int.Parse(Console.ReadLine());
                        ddl.FindPos(data,pos);
                        break;
                    case 9:
                        ddl.display();
                        break;
                    case 10: break;
                    default: Console.WriteLine("invalid choice"); break;


                }
            } while (ch != 10);
    }
}
}